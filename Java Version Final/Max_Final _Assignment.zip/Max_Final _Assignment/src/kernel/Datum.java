package kernel;
import processing.core.*;
import processing.data.*;

public class Datum {
  public String country;
  public String year;
  public String job;
  public float attrition;
  public int col;
}
